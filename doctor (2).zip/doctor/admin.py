from django.contrib import admin
from doctor.models import *
# Register your models here.
admin.site.register(Booking)