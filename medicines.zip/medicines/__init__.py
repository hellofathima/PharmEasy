# medicine/__init__.py

default_app_config = 'medicine.apps.MedicineConfig'
