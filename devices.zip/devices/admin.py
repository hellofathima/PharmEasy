from django.contrib import admin
from devices.models import *
# Register your models here.
admin.site.register(DeviceInformation)